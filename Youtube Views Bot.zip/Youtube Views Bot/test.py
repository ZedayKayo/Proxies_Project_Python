z=0
y=1
proxies =["11111111","222222222","333333333","444444444444"]
while(z < len(proxies)):
    proxies_count_to_check = 2
    for i in range(z , proxies_count_to_check*y):
        print("z -->"+proxies[z])
        z+=1  
    print("loop z -->"+str(z))
    print("loop y -->"+str(y))
    
    y+=1  