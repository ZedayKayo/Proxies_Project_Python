import requests
from bs4 import BeautifulSoup
import os

def get_free_proxies():
    url = "https://www.sslproxies.org/"  # Example URL for free proxies
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    # Start from the second row to skip the table header
    proxies = [f"{row.find_all('td')[0].text}:{row.find_all('td')[1].text}" for row in soup.find_all("tr")[1:] if len(row.find_all('td')) >=  2]
    return proxies


def save_valid_proxy(proxy):
    # Define the directory and file paths
    dir_path = 'info'  # The directory where you want to save the file
    file_path = os.path.join(dir_path, 'valid_proxies.txt')  # The path to the file
    
    # Check if the directory exists, if not, create it
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)  # Creates the directory if it doesn't exist
    
    # Check if the file exists, if not, create it
    if not os.path.isfile(file_path):
        with open(file_path, 'w') as file:  # Opens the file in write mode, creating it if it doesn't exist
            file.write(proxy + '\n')  # Writes the proxy to the file
    else:
        # If the file exists, append the valid proxy to it
        with open(file_path, 'a') as file:  # Opens the file in append mode
            file.write(proxy + '\n')  # Appends the proxy to the file


def test_proxy(proxy):
    test_url = "http://www.google.com"
    try:
        response = requests.get(test_url, proxies={"http": proxy, "https": proxy}, timeout=5)
        print('request is sent to test this proxy ---> '+str(proxy))
        if response.status_code ==  200:
            # Proxy is valid
            save_valid_proxy(proxy)
            print(str(proxy)+' ------> This Proxy is saved')
            return True
        else:
            return False
    except requests.exceptions.RequestException:
        return False



# Call the function and print the proxies
proxies = get_free_proxies()
print("################################################")
print("Printing All The Extracted Free Proxies..")
for proxy in proxies:
    print(proxy)
    test_proxy(proxy)

print("################################################")   