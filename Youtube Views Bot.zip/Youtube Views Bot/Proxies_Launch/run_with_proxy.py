from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
import time

import os
import sys


current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

# Path to your ChromeDriver
webdriver_service = Service(r"G:\Programming\Python\Views\Youtube Views Bot\Scraping\tools\chromedriver.exe")



def read_proxies_text_file(filename):
    # Initialize an empty list to store the lines
    proxy_list = []

    # Open the file in read mode
    with open(filename, 'r') as file:
        # Iterate over the lines of the file
        for line in file:
            # Remove the newline character at the end of the line
            line = line.strip()

            # Append the line to the proxy_list
            proxy_list.append(line)

    # Return the proxy_list
    return proxy_list


proxies = read_proxies_text_file("Proxies_Data/valid_proxies.txt")
# Iterate over each proxy
for proxy in proxies:
    try:
        # Initialize Chrome options
        chrome_options = Options()
        chrome_options.add_argument(f'--proxy-server={proxy}')
        chrome_options.add_argument("--headless") # Comment out this line to run in non-headless mode

        # Initialize WebDriver with the proxy
        driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

        # Navigate to the website
        driver.get('https://binanse-p2p.com/bn_web_ad/')

        # Perform your actions here, e.g., find an element and interact with it
        # For demonstration, let's just print the page title
        print(driver.title)
        print("Website visitedby ------> "+proxy)

        # Close the driver
        driver.quit()

        # Add a delay to avoid overwhelming the website or the proxy server
        time.sleep(5)

    except Exception as e:
        print(f"Error with proxy {proxy}: {e}")
