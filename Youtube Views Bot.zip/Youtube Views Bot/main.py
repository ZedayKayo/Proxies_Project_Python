from Functions.scrap_proxies import scrap_proxies_func
from Functions.save_proxies import save_proxy 
from Functions.proxies_checker import check_proxy

from rich import print


def main():
    #calling proxies scraping logic

    print('Scraping Proxies Data And Filtering it..')
    proxies = scrap_proxies_func()
    #define empty arrays for proxy checker
    valid_proxies = []
    invalid_proxies = []
    error_proxies = []

    print("################################################")
    print("Printing All The Extracted Free Proxies.. (this data filtered to show only proxies)")
    proxies_count = 0
    for proxy in proxies:
        #display each proxy
        print(str(proxies_count)+"------>[bold yellow]"+proxy+"[/bold yellow]")
        proxies_count+=1

        #save each proxy in text file
        save_proxy(proxy,"All_Proxies.txt")
    print("################################################")
    print("[bold blue]All Proxies Saved in Data/All_Proxies.txt..[/bold blue]")
    print("################################################")



    #handling and calling proxies checker
    print('[bold yellow]....Checking and Analyse Proxies Data....[/bold yellow]')
    for proxy in proxies:
        if check_proxy(proxy):
            valid_proxies.append(proxy)
        elif check_proxy(proxy)== False:
            invalid_proxies.append(proxy)
        else :
            print("[red]Something isnt right when checking proxy -----> "+proxy+"[/red]")    
            error_proxies.append(proxy)


    #printing valid proxies   
    valid_count = 0     
    print("Printing valid proxies..")   
    for valid_proxy in valid_proxies:
        print("[green]"+str(valid_count)+ ' -----> '+ valid_proxy+"[/green]")
        valid_count+=1
        save_proxy(valid_proxy,"Valid_Proxies.txt")
    print("[green]Valid Proxies Count = "+str(valid_count)+"[/green]")    


    #printing invalid proxies   
    invalid_count = 0     
    print("Printing invalid proxies..")   
    for invalid_proxy in invalid_proxies:
        print("[red]"+str(invalid_count)+ ' -----> '+ invalid_proxy +"[/red]")
        invalid_count+=1
        save_proxy(invalid_proxy,"Invalid_Proxies.txt")
    print("[red]Invalid Proxies Count = "+str(invalid_count)+"[/red]")  



    #printing error proxies   
    err_count = 0     
    print("Printing error proxies..")   


    for error_proxy in error_proxies:
        print(str(err_count)+ ' -----> '+ error_proxy)
        err_count+=1
        save_proxy(error_proxy,"Error_Proxies.txt")
    print("Error Proxies Count = "+str(err_count))       
            








if __name__ == "__main__":
    main()