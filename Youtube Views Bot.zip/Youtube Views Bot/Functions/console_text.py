import os
import datetime

def ConsoleText(text, filename='Console.txt'):
    # Get the current date and time
    current_time = datetime.datetime.now()

    # Format the current date and time as a string
    time = current_time.strftime("%Y-%m-%d %H:%M:%S")
   # Define the directory and file paths
    dir_path = 'Proxies_Data'  # The directory where you want to save the file
    file_path = os.path.join(dir_path, filename)  # The path to the file
    
    # Check if the directory exists, if not, create it
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)  # Creates the directory if it doesn't exist
    
    
    # If the file doesn't exist or the proxy is not in the file, append the proxy
    with open(file_path, 'a') as file:
        file.write(text + " ---------->"+ time +'\n')  # Appends the proxy to the file

def Clear_ConsoleText(filename='Console.txt'):
   # Define the directory and file paths
    dir_path = 'Proxies_Data'  # The directory where you want to save the file
    file_path = os.path.join(dir_path, filename)  # The path to the file
    
    # Check if the directory exists, if not, create it
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)  # Creates the directory if it doesn't exist
    
    
    # Clear the file before adding new text
    with open(file_path, 'w') as file:
        pass # This opens the file in write mode, clearing its contents

