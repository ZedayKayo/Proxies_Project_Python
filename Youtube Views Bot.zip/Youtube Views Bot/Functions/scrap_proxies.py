import requests
from bs4 import BeautifulSoup
import re

def get_free_proxies():
    url = "https://www.sslproxies.org/"  # Example URL for free proxies
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    # Start from the second row to skip the table header
    proxies = [f"{row.find_all('td')[0].text}:{row.find_all('td')[1].text}" for row in soup.find_all("tr")[1:] if len(row.find_all('td')) >=  2]
    return proxies


def scrap_proxies_func():
    proxies = []
    prxs = get_free_proxies()
    for proxy in prxs:
        if(is_it_proxy(proxy)):
            proxies.append(proxy)
        else:
            print("This is not a Proxy ---> "+str(proxy))    

    print("Proxies Data Is Filtered Successfully..")
    return proxies  




def is_valid_ip(ip):
    """Check if IP address is valid."""
    if ip.count('.') !=  3:
        return False
    for segment in ip.split('.'):
        if not segment.isdigit() or not  0 <= int(segment) <=  255:
            return False
    return True

def is_valid_port(port):
    """Check if port is valid."""
    if not port.isdigit():
        return False
    return  0 < int(port) <  2**16

def is_it_proxy(proxy):
    """Check if a string is a valid proxy address."""
    # Regex pattern to match proxy format: user:password@ip:port
    pattern = r'^((([^:]+):([^@]+))@)?((\d{1,3}\.){3}\d{1,3})(:(\d{1,5}))?$'
    match = re.match(pattern, proxy)
    if not match:
        return False
    ip = match.group(5)
    port = match.group(8)
    if not is_valid_ip(ip):
        return False
    if port and not is_valid_port(port):
        return False
    return True