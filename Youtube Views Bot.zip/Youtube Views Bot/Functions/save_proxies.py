import os

def save_proxy(proxy, file_name):
    # Define the directory and file paths
    dir_path = 'Proxies_Data'  # The directory where you want to save the file
    file_path = os.path.join(dir_path, file_name)  # The path to the file
    
    # Check if the directory exists, if not, create it
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)  # Creates the directory if it doesn't exist
    
    # Check if the file exists
    if os.path.isfile(file_path):
        # If the file exists, check if the proxy is already in the file
        with open(file_path, 'r') as file:
            if proxy + '\n' in file.readlines():
                # If the proxy is already in the file, do nothing
                return

    # If the file doesn't exist or the proxy is not in the file, append the proxy
    with open(file_path, 'a') as file:
        file.write(proxy + '\n')  # Appends the proxy to the file

def clear_proxy_file(file_name):
   # Define the directory and file paths
    dir_path = 'Proxies_Data'  # The directory where you want to save the file
    file_path = os.path.join(dir_path, file_name)  # The path to the file
    
    # Check if the directory exists, if not, create it
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)  # Creates the directory if it doesn't exist
    
    
    # Clear the file before adding new text
    with open(file_path, 'w') as file:
        pass # This opens the file in write mode, clearing its contents

