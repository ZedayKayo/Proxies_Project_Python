import requests
from rich import print


def check_proxy(prxy):
    proxy = "http://"+str(prxy)
    print("[bold blue]Proccessing [/bold blue][green]"+str(proxy)+"[/green] [bold blue]...[/bold blue]")
    test_url = "http://www.google.com"
    try:
        response = requests.get(test_url, proxies={"http": proxy, "https": proxy}, timeout=5)
        print('request is sent to check this proxy with http  ---> '+str(proxy))
        if response.status_code ==  200:
            # Proxy is valid
            print("[green]"+str(proxy)+' ------> Valid Proxy [/green]')
            return True
        else:
            print("[red]"+str(proxy)+' ------> Invalid Proxy [/red]')
            print("[bold blue]lets test it again with https...[/bold blue]")
            
            proxy = "https://"+str(prxy)
            response = requests.get(test_url, proxies={"http": proxy, "https": proxy}, timeout=5)
            print('request is sent to check this proxy with https ---> '+str(proxy))
            if response.status_code ==  200:
                # Proxy is valid
                print("[green]"+str(proxy)+' ------> Valid Proxy [/green]')
                return True
            else:
                return False
    except requests.exceptions.RequestException as e:
        print(str(proxy)+" ---> Can't check this proxy in test_proxy function: ", e)

        
        
        
