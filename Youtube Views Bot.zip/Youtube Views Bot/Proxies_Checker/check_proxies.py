from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.common.exceptions import NoSuchElementException
import os
import sys
from selenium.common.exceptions import ElementNotInteractableException

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)
from Functions.scrap_proxies import is_it_proxy
from Functions.save_proxies import save_proxy , clear_proxy_file
from Functions.console_text import ConsoleText , Clear_ConsoleText



def driver_config(port):
    try:
        chrome_options = Options()
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--no-sandbox")
        #chrome_options.add_argument("--headless") # Comment out this line to run in non-headless mode
        
        service = Service(r"G:\Programming\Python\Views\Youtube Views Bot\Scraping\tools\chromedriver.exe")
        
        print("Trying to launch the browser")
        # Create a new instance of the Chrome driver without setting the port yet
        driver = webdriver.Chrome(service=service, options=chrome_options)
        
        print("browser opened seccessfully")
        # Now call the set_and_return_driver function to set the port
        driver.service.port = port
        
        print("port sat seccessfully")
        
        driver.maximize_window()
        print("browser maximized seccessfully")
        return driver, True
    except Exception as e:
        print(f"An error occurred inside driver_config function : {e}")
        return None, False

def Check_Proxies(driver,url,proxy_list):
    close_notification(driver)

    ConsoleText("Checking Proxies....In ------> "+url)
    
    ConsoleText("Proxies Count To Check.... ------> "+str(len(proxy_list)))    
    
    proxies_count_to_check = 50
    if(len(proxy_list)>100):
        times_to_repeat_while =  len(proxy_list) / proxies_count_to_check
        ConsoleText("There is too many proxies to check, to avoid website crashing lets split proxies and check each  "+str(proxies_count_to_check)+" proxy in loop") 
        ConsoleText("The Count Of Proxies Parts is .... ------> "+str(int(times_to_repeat_while)))  

        z=0
        y=1
        while(y <= int(times_to_repeat_while)):
            driver.refresh()
            proxies =[] 
            time.sleep(3)


            close_notification(driver)
            # Locate the textarea and add proxy list
            proxy_list_textarea = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "proxy_list"))
            )
            
            # Clear the textarea (optional)
            proxy_list_textarea.clear()

            proxies_chunk = []
            for i in range(z , proxies_count_to_check*y):
                close_notification(driver)

                # Convert the list to a string with each element on a new line
                proxies_chunk.append(proxy_list[i])
                z+=1
            
            proxy_list_to_add = "\n".join(proxies_chunk)


            close_notification(driver)

            proxy_list_textarea.send_keys(proxy_list_to_add)

            close_notification(driver)
            ConsoleText("Proxies Added To The Website...Proxies part "+str(y))
            print("Text added")
            # Locate the button by ID and click it
            check_proxies_button = driver.find_element(By.ID, "proxy_button")
            close_notification(driver)
            check_proxies_button.click()
            close_notification(driver)
            print("Check proxies button clicked") 
            ConsoleText("Check Proxies Button Clicked")  
            time.sleep(1)
            close_notification(driver)
            
            ConsoleText("Waiting For Checking To End..")  

            #waiting fro checker to end
            while True:
                close_notification(driver)
                # Locate the elements by their CSS selectors
                working_proxies_span = driver.find_element(By.ID, 'working_proxies')
                dead_proxies_span = driver.find_element(By.ID, 'dead_proxies')
                total_proxies_span = driver.find_element(By.CSS_SELECTOR, '.badge-secondary.badge-pill')

                # Extract the text content of the elements
                working_proxies_value = int(working_proxies_span.text)
                dead_proxies_value = int(dead_proxies_span.text)
                total_proxies_value = int(total_proxies_span.text)

                # Compare the values and print the appropriate message
                if working_proxies_value + dead_proxies_value == total_proxies_value:
                    print("Checker is done")
                    close_notification(driver)
                    break # Exit the loop when the condition is met
                else:
                    close_notification(driver)
                    print("Still checking..")
                    # Optionally, add a delay here if needed
                    # time.sleep(5) # Wait for 5 seconds before checking again

            
            close_notification(driver)
            tr_rows = driver.find_elements(By.TAG_NAME, "tr")


            http_s_valid_proxies = []
            socks_valid_proxies = []
            # Iterate through each row
            for row in tr_rows:
                close_notification(driver)
                # Check if the row has the class 'table-success'
                if 'table-success' in row.get_attribute('class'):
                    # Find all td elements within the current row
                    tds = row.find_elements(By.TAG_NAME, "td")
                    close_notification(driver)
                    # Check if there are at least 3 td elements
                    if len(tds) >= 3:
                        # Extract the contents of the second and third td elements
                        ip = tds[1].text
                        port = tds[2].text
                        proxy_type = tds[4].text
                        # Concatenate the contents with a colon
                        proxy = f"{ip}:{port}"

                        print("Valid proxy ---->"+proxy)
                        ConsoleText("Valid proxy ---->"+str(proxy))
                        save_proxy(proxy,"valid_proxies.txt")
                        # Add the concatenated string to the proxy list
                        if proxy_type == "socks4" or proxy_type =="socks5":
                            socks_valid_proxies.append(proxy)
                        if proxy_type == "http" or proxy_type =="https":
                            http_s_valid_proxies.append(proxy)
                elif 'table-danger' in row.get_attribute('class'):
                    # Find all td elements within the current row
                    tds = row.find_elements(By.TAG_NAME, "td")

                    close_notification(driver)
                    # Check if there are at least 3 td elements
                    if len(tds) >= 3:
                        # Extract the contents of the second and third td elements
                        ip = tds[1].text
                        port = tds[2].text
                     # Concatenate the contents with a colon
                        proxy = f"{ip}:{port}"
                        print("invalid proxy ---->"+proxy)
                        ConsoleText("invalid proxy ---->"+str(proxy))
                        save_proxy(proxy,"invalid_proxies.txt")
                else:
                    close_notification(driver)
                    print("still checking...")



                close_notification(driver)

                # Print the http_s_valid_proxies
                valid_cnt=1
                close_notification(driver)
                for proxy in http_s_valid_proxies:
                    close_notification(driver)
                    print(str(valid_cnt)+" ....Valid proxy ---> "+proxy)
                    close_notification(driver)
                    save_proxy(proxy,"../Proxies_Data/http_s_valid_proxies.txt") 
                    close_notification(driver)
                    valid_cnt+=1
                    close_notification(driver)
                    close_notification(driver)
                    # Print the socks_valid_proxies
                    valid_cnt=1
                for proxy in socks_valid_proxies:
                    close_notification(driver)
                    print(str(valid_cnt)+" ....Valid proxy ---> "+proxy)
                    close_notification(driver)
                    save_proxy(proxy,"../Proxies_Data/socks_valid_proxies.txt") 
                    close_notification(driver)
                    valid_cnt+=1
                    close_notification(driver)

                    close_notification(driver)

               

            y+=1
        ConsoleText(str(z))
        proxy_list_last_index = len(proxy_list)
        #clear the checked proxies from proxies.txt   
        clear_proxy_file('proxies.txt')
        ConsoleText( str( proxy_list_last_index ) )

        #add the unchecked proxies in proxies.txt   
        for i  in range(z,proxy_list_last_index):
            ConsoleText(str(i)+" -----> "+proxy_list[i])
            save_proxy(proxy_list[i],'proxies.txt')

        
        ConsoleText("Checking Proccess Completed..") 
    else:
        ConsoleText("Script Programmed To Not Check Proxies Only if There more then.."+str(proxies_count_to_check)+" proxy.")
        close_notification(driver)
        time.sleep(3)
        close_notification(driver)
    
    print("All Proxies Is Checked And Saved Succesully...") 
    ConsoleText("All Proxies Is Checked And Saved Succesully...") 
       
            

def close_notification(driver):
    try:
        # Try to find the button by ID
        button = driver.find_element(By.ID, "sumter-NoButtonElement--YfDbMve5BuKs3o28AyaB")
        # If the button exists, click it
        button.click()
    
    except ElementNotInteractableException:
        # If the element is not interactable, use JavaScript to click it
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        # If the element is not found, do nothing or handle it as needed
        print("no notification found to close")
        pass



def read_proxies_text_file(filename):
    # Initialize an empty list to store the lines
    proxy_list = []

    # Open the file in read mode
    with open(filename, 'r') as file:
        # Iterate over the lines of the file
        for line in file:
            # Remove the newline character at the end of the line
            line = line.strip()

            # Append the line to the proxy_list
            proxy_list.append(line)

    # Return the proxy_list
    return proxy_list


 
def main():
    Clear_ConsoleText()
    current_port =  9515
    driver, success = driver_config(current_port)
    url = "https://proxyscrape.com/online-proxy-checker"

    # Open the URL
    driver.get(url)
    # Example usage:
    proxy_list = read_proxies_text_file('Proxies_Data/proxies.txt')
    time.sleep(3)
    close_notification(driver)
    
    proxu_count=1
    http_s_valid_proxies = [] 

    close_notification(driver)
    Check_Proxies(driver,url,proxy_list)
    close_notification(driver)

    #for proxy in proxy_list:
    #    if is_it_proxy(proxy):
    #        print(str(proxu_count)+" ---> "+proxy)
#
    #        proxu_count+=1

    #if success:
    #    try:
    #        proxies = extract_proxies_from_freeproxylistnet(driver)
    #        driver.quit()
    #        
    #    except Exception as e:
    #        print("An error occurred:", e)
    #        driver.quit()


if __name__ == "__main__":
    
    main()
