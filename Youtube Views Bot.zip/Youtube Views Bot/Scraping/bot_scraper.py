from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver import ActionChains
import re
import os
import sys

# Get the current script directory
current_dir = os.path.dirname(os.path.abspath(__file__))

# Get the parent directory
parent_dir = os.path.dirname(current_dir)

# Add the parent directory to sys.path
sys.path.append(parent_dir)

from Functions.proxies_checker import check_proxy
from Functions.save_proxies import save_proxy


def driver_config(port):
    try:
        chrome_options = Options()
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--headless") # Comment out this line to run in non-headless mode
        
        service = Service(r"G:\Programming\Python\Views\Youtube Views Bot\Scraping\tools\chromedriver.exe")
        
        print("Trying to launch the browser")
        # Create a new instance of the Chrome driver without setting the port yet
        driver = webdriver.Chrome(service=service, options=chrome_options)
        
        print("browser opened seccessfully")
        # Now call the set_and_return_driver function to set the port
        driver.service.port = port
        
        print("port sat seccessfully")
        
        driver.maximize_window()
        print("browser maximized seccessfully")
        return driver, True
    except Exception as e:
        print(f"An error occurred inside driver_config function : {e}")
        return None, False

def extract_proxies_from_freeproxylistnet(driver):
    
    # Open the URL
    url = "https://free-proxy-list.net/"
    driver.get(url)
    proxies =[] 
    time.sleep(5)
    # Find all tr elements
    trs = driver.find_elements(By.TAG_NAME, "tr")
    
    count_proxies=1
    print("Scraping Proxies....FROM ------> https://free-proxy-list.net/")
    for tr in trs:
        # Find all td elements within the current tr
        tds = tr.find_elements(By.TAG_NAME, "td")
        
        if tds:  # Ensure there are td elements to process
            # Extract the IP address and port
            ip = tds[0].text
            port = tds[1].text
            
            # Combine IP and port into address format
            address = f"{ip}:{port}"
            # save address in proxies list
            proxies.append(address)
            count_proxies+=1

    return proxies        
            

def extract_proxies_from_websites_that_have_proxies_inside_pre_tag(driver,link):

    url = link  # Replace with the actual URL
    try:
        driver.get(url)
        
        print("Scraping Proxies....FROM ------> "+str(url))
        time.sleep(5)
        pre_content = driver.find_element(By.TAG_NAME, "pre").text
        proxy_pattern = r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}\b"
        proxies = re.findall(proxy_pattern, pre_content)  # Adjust the split character based on how proxies are separated
    
        # Now, proxies is a list of strings, each containing a proxy
        return proxies 
    except:
        print("an excpetion is raised when trying to scrap proxies from pre tag website -----> " + str(url))
        


def main():
    
    current_port =  9515
    driver, success = driver_config(current_port)
    proxies_count = 1
    websites_urls_with_pre_tag_urls = [
        "https://3doyunindir.blogspot.com/feeds/posts/default?alt=rss",
        "http://globalproxies.blogspot.de/feeds/posts/default",
        "https://multiproxy.org/txt_all/proxy.txt",
        "http://0dayproxies.blogspot.com/feeds/posts/default?alt=rss",
        "http://1000freeanonymousproxy.blogspot.com/feeds/posts/default?alt=rss",
        "https://100proxygratis.blogspot.com/feeds/posts/default?alt=rss",
        "http://2freesocks5list.blogspot.com/feeds/posts/default?alt=rss",
        "http://7proxy.blogspot.com/feeds/posts/default?alt=rss",
        "http://8proxy.blogspot.com/feeds/posts/default?alt=rss",
        "http://accforfree.blogspot.com/feeds/posts/default?alt=rss",
        "http://actualproxy.blogspot.com/feeds/posts/default?alt=rss",
        "http://adan82222.blogspot.com/feeds/posts/default?alt=rss",
        "http://adminsarhos.blogspot.com/feeds/posts/default?alt=rss",
        "http://advanceauto-show.blogspot.com/feeds/posts/default?alt=rss",
        "http://akatsukihackblog.blogspot.com/feeds/posts/default?alt=rss",
        "http://alivevpn.blogspot.com/feeds/posts/default?alt=rss",
        "http://alldayproxy.blogspot.com/feeds/posts/default?alt=rss",
        "http://amisauvveryspecial.blogspot.com/feeds/posts/default?alt=rss",
        "http://anondwahyu.blogspot.com/feeds/posts/default?alt=rss",
        "http://anonimseti.blogspot.com/feeds/posts/default?alt=rss",
        "http://anonproxylist.blogspot.com/feeds/posts/default?alt=rss",
        "http://anonymousproxyblog.blogspot.com/feeds/posts/default?alt=rss",
        "http://apexgeeky.blogspot.com/feeds/posts/default?alt=rss",
        "http://applebaby2013.blogspot.com/feeds/posts/default?alt=rss",
        "http://asdfg3ffasdasdasd.blogspot.com/feeds/posts/default?alt=rss",
    ]

    if success:
        try:
            proxies = extract_proxies_from_freeproxylistnet(driver)
            driver.quit()
            
            for proxy in proxies:
                print(str(proxies_count)+' -----> '+proxy)
                proxies_count+=1
                
                save_proxy(proxy,"proxies.txt")
                #valid_proxy = check_proxy(proxy)
                #if valid_proxy == True:
                #    save_proxy(proxy,"prxs_valid.txt")
                #elif valid_proxy == False:
                #    save_proxy(proxy,"prxs_invalid.txt")
                #else:    
                #    save_proxy(proxy,"prxs_error.txt")
#
        except Exception as e:
            print("An error occurred:", e)
            driver.quit()
        #websites_count =  1
        #for website_with_pre_tag_url in websites_urls_with_pre_tag_urls:
        #    try:
        #        
        #        current_port =  9515
        #        driver, success = driver_config(current_port)
        #        url = website_with_pre_tag_url
        #        proxies = extract_proxies_from_websites_that_have_proxies_inside_pre_tag(driver,url)
        #        driver.quit()
        #        for proxy in proxies:
        #            save_proxy(proxy,str(websites_count)+".txt")
        #            print(str(proxies_count)+' -----> '+proxy)
        #            #valid_proxy = check_proxy(proxy)
        #            #if valid_proxy:
        #            #    save_proxy(proxy,str(websites_count)+"_valid.txt")
        #            #elif valid_proxy == False:
        #            #    save_proxy(proxy,str(websites_count)+"_invalid.txt")
        #            #else:    
        #            #    save_proxy(proxy,str(websites_count)+"_error.txt")
#
        #            proxies_count+=1
        #        websites_count+=1
        #    except Exception as e:
        #        print("An error occurred:", e)


if __name__ == "__main__":
    
    main()
    print("Proxies Checked And And Saved Succesfully..")
    print("Http/Https Proxies Saved In Proxies_Data/http_s_valid_proxies.txt")
    print("socks4/socks5 Proxies Saved In Proxies_Data/socks_valid_proxies.txt")
